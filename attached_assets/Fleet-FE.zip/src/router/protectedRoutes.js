import React from "react";
import { Navigate } from "react-router-dom";

const ProtectedRoute = ({ children }) => {
  const user = localStorage.getItem("user");

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  return children;
};

const ProtectedAuthRoute = ({ children }) => {
  const user = localStorage.getItem("user");

  if (user) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

const ProtectedOnBoardingRoute = ({ children }) => {
  const email = localStorage.getItem("email");

  if (!email) {
    return <Navigate to="/auth" replace />;
  }

  return children;
};

const ProtectedHomeownerRoute = ({ children }) => {
  const user = JSON.parse(localStorage.getItem("user"));

  if (user?.role !== "homeowner") {
    return <Navigate to="/" replace />;
  }

  return children;
};

const ProtectedContactorRoute = ({ children }) => {
  const user = JSON.parse(localStorage.getItem("user"));

  if (user?.role !== "contactor") {
    return <Navigate to="/" replace />;
  }

  return children;
};

export {
  ProtectedRoute,
  ProtectedAuthRoute,
  ProtectedOnBoardingRoute,
  ProtectedHomeownerRoute,
  ProtectedContactorRoute,
};
