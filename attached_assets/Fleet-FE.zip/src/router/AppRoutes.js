import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Register from "../pages/auth/Register";
import LandingPage from "../pages/LandingPage/index";
import ForgetPassword from "../pages/auth/forgetPassword";
import OnBoarding from "../pages/auth/onBoarding";
import Dashboard from "../pages/dashboard/index";
import Cards from "../pages/auth/cards";
import {
  ProtectedRoute,
  ProtectedAuthRoute,
  ProtectedOnBoardingRoute,
} from "./protectedRoutes";
import Loader from "../components/loader";

const AppRoutes = () => {
  return (
    <React.Suspense fallback={<Loader />}>
      <BrowserRouter>
        <Routes>
          <Route
            path="/"
            element={
              <ProtectedAuthRoute>
                <Register />
              </ProtectedAuthRoute>
            }
          />
          <Route
            path="/dashboard*"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/auth"
            element={
              <ProtectedAuthRoute>
                <Register />
              </ProtectedAuthRoute>
            }
          />
          <Route
            path="/forget-password"
            element={
              <ProtectedAuthRoute>
                <ForgetPassword />
              </ProtectedAuthRoute>
            }
          />
          <Route
            path="/onboarding"
            element={
              <ProtectedOnBoardingRoute>
                <OnBoarding />
              </ProtectedOnBoardingRoute>
            }
          />
        </Routes>
      </BrowserRouter>
    </React.Suspense>
  );
};

export default AppRoutes;
