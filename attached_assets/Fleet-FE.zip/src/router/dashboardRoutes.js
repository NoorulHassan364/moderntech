import React, { lazy } from "react";
import { Routes, Route, Brow } from "react-router-dom";
import Loader from "../components/loader/index";

const Dashboad = lazy(() => import("../pages/dashboard/dashboard"));
const Proposal = lazy(() => import("../pages/dashboard/proposal"));
const JobDetail = lazy(() => import("../pages/dashboard/job-detail"));

const AdminRoutes = () => {
  return (
    <React.Suspense fallback={<Loader />}>
      <Routes>
        <Route path="/" element={<Dashboad />} />
        <Route path="/proposal" element={<Proposal />} />
        <Route path="/job-detail/:id" element={<JobDetail />} />
      </Routes>
    </React.Suspense>
  );
};

export default AdminRoutes;
