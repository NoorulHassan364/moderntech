import React, { useState } from "react";
import "./style.css";
import { Button, Col, message, Row } from "antd";
import { Link, useNavigate } from "react-router-dom";
const Index = () => {
  const navigate = useNavigate();
  const [active, setActive] = useState(null);
  const handleNext = () => {
    if (!active) {
      message.error({ content: "Please Select any one" });
    } else {
      navigate(`auth/?role=${active}`);
    }
  };
  return (
    <div className="cards-main">
      <div className="cards-form">
        <div>
          <div className="header">Choose option that best describes you</div>
          <div
            className={`card ${active == "homeowner" ? "active-card" : ""}`}
            onClick={() => setActive("homeowner")}
          >
            Home owner
          </div>
          <div
            className={`card ${active == "contractor" ? "active-card" : ""}`}
            onClick={() => setActive("contractor")}
          >
            Contractor
          </div>
          <Button
            type="primary"
            onClick={handleNext}
            style={{ marginTop: "1rem" }}
          >
            Next
          </Button>
          <div className="login">
            <span>
              Already a member? <Link to="/auth?login=true">Login</Link>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
