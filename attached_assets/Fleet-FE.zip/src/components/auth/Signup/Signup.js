import { Checkbox, Form, Radio, Select, Spin, Input } from "antd";
import { Content } from "antd/es/layout/layout";
import React, { useState } from "react";
import api from "../../../api";

const Signup = ({ setActive, setCodeModal, setUserId, role }) => {
  const [form] = Form.useForm();
  const [loader, setLoader] = useState(false);
  const [email, setEmail] = useState("");

  const onHandleSubmit = async (values) => {
    // alert(JSON.stringify(values));
    console.log(values);
    setLoader(true);
    const result = await api.post("/auth/signup", { ...values, role: role });
    debugger;
    if (result?.status == 201) {
      setCodeModal(true);
      setUserId(result?.data?.data?._id);
      // localStorage.setItem("user", JSON.stringify(result?.data?.data));
      form.resetFields();
    }
    setLoader(false);
  };
  return (
    <Content>
      <Form className="signup-form" onFinish={onHandleSubmit} form={form}>
        <div>
          <div className="form-title">Email</div>
          <Form.Item
            name="email"
            rules={[
              { required: true, message: "required!" },
              { type: "email", message: "invalid email" },
            ]}
          >
            <Input
              className="input"
              type="email"
              placeholder="example@gmail.com"
              autoComplete="off"
            />
          </Form.Item>
        </div>
        <div>
          <div className="form-title">Password</div>
          <Form.Item
            name="password"
            rules={[
              { required: true, message: "required!" },
              { min: 6, message: "at-least 6 characters" },
            ]}
          >
            <Input.Password className="input" placeholder="••••••" />
          </Form.Item>
        </div>
        <div>
          <div className="form-title">Confirm Password</div>

          <Form.Item
            name="confirm"
            dependencies={["password"]}
            hasFeedback
            rules={[
              {
                required: true,
                message: "Please confirm your password!",
              },
              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue("password") === value) {
                    return Promise.resolve();
                  }
                  return Promise.reject(
                    new Error("The new password that you entered do not match!")
                  );
                },
              }),
            ]}
          >
            <Input.Password className="input" placeholder="••••••" />
          </Form.Item>
        </div>
        <div>
          <Form.Item
            name="terms"
            valuePropName="checked"
            dependencies={["password"]}
            rules={[
              {
                validator: (_, value) =>
                  value
                    ? Promise.resolve()
                    : Promise.reject(
                        new Error(
                          "Please accept the terms of service and privacy policy to continue."
                        )
                      ),
              },
            ]}
          >
            <Checkbox>
              I accept the{" "}
              <span style={{ fontWeight: "bold" }}>terms of service</span> and
              <span style={{ fontWeight: "bold" }}> privacy policy</span> to
              continue
            </Checkbox>
          </Form.Item>
        </div>
        {loader ? (
          <div style={{ textAlign: "center" }}>
            <Spin />
          </div>
        ) : (
          <button>Continue</button>
        )}
      </Form>
    </Content>
  );
};

export default Signup;
