import React, { useState, useEffect } from "react";
import {
  Form,
  Input,
  Button,
  Checkbox,
  Image,
  Layout,
  Typography,
  Spin,
  Modal,
} from "antd";
import {
  LockOutlined,
  RedoOutlined,
  SearchOutlined,
  UnlockOutlined,
  UserOutlined,
} from "@ant-design/icons";

import { Row, Col } from "antd";
import { useNavigate, Link, Navigate } from "react-router-dom";
import "./style.css";
import api from "../../../api";

const { Title } = Typography;

const ForgetPassword = () => {
  const navigate = useNavigate();
  const [isActive, setActive] = useState(false);
  const [form] = Form.useForm();
  const [email, setEmail] = useState(null);

  const handleSubmit = async (values) => {
    let res = await api.post("/auth/forget-password", values);
    if (res.status == 200) {
      setEmail(values.email);
    }
  };

  const handleResendSendCode = async () => {
    let res = await api.post("/auth/forget-password", { email: email });
    if (res.status == 200) {
      setEmail({ email: email });
    }
  };

  const handleSubmit2 = async (values) => {
    let res = await api.post("/auth/reset-password", values);
    if (res.status == 200) {
      localStorage.setItem("user", JSON.stringify(res?.data?.data));
      navigate("/");
    }
  };

  return (
    <Layout className="forgetPassword-main">
      {email ? (
        <div className="forget-password-form">
          <RedoOutlined
            style={{ fontSize: 40, color: "blue", marginBottom: 20 }}
          />

          <Title level={5} style={{ color: "gray", marginBottom: 20 }}>
            Reset Account Passsword
          </Title>
          <Form
            form={form}
            layout="vertical"
            name="form_in_modal"
            onFinish={handleSubmit2}
          >
            <Form.Item
              name="token"
              rules={[
                {
                  required: true,
                  message: "Required",
                },
              ]}
            >
              <Input
                type="text"
                placeholder="Enter verification code"
                prefix={<LockOutlined />}
                size="medium"
              />
            </Form.Item>

            <div
              style={{
                display: "flex",
                width: "100%",
                justifyContent: "space-between",
              }}
            >
              <div style={{ display: "flex" }}>
                <p>Didn't get code?</p>
                <Link
                  to="#"
                  onClick={() => handleResendSendCode()}
                  style={{ marginLeft: "0.3rem" }}
                >
                  resend
                </Link>
              </div>
            </div>

            <Form.Item
              name="password"
              rules={[
                {
                  required: true,
                  message: "Required",
                },
                {
                  message: "password at-least 6 characters",
                  min: 6,
                },
              ]}
            >
              <Input
                type="password"
                placeholder="Enter new password"
                prefix={<LockOutlined />}
                size="large"
              />
            </Form.Item>

            <Form.Item
              name="confirmPassword"
              rules={[
                {
                  required: true,
                  message: "Please confirm your password!",
                },
                ({ getFieldValue }) => ({
                  validator(_, value) {
                    if (!value || getFieldValue("password") === value) {
                      return Promise.resolve();
                    }
                    return Promise.reject(
                      new Error(
                        "The two passwords that you entered do not match!"
                      )
                    );
                  },
                }),
              ]}
            >
              <Input
                type="password"
                placeholder="Confirm password"
                prefix={<LockOutlined />}
                size="large"
              />
            </Form.Item>

            <Form.Item style={{ marginTop: "20px" }}>
              {isActive === false ? (
                <Button
                  className="login-form-button"
                  htmlType="submit"
                  type="primary"
                  block
                >
                  Submit
                </Button>
              ) : (
                <Button
                  className="login-form-button"
                  htmlType="submit"
                  type="primary"
                  block
                  disabled
                >
                  <Spin
                    style={{
                      justifyContent: "center",
                      alignItems: "center",
                      display: "flex",
                    }}
                  />
                </Button>
              )}
            </Form.Item>
          </Form>
        </div>
      ) : (
        <div className="forget-password-form">
          <RedoOutlined
            style={{ fontSize: 40, color: "blue", marginBottom: 20 }}
          />
          <Title level={4} style={{ color: "gray", marginBottom: 10 }}>
            Lost Your Password?
          </Title>

          <Form
            form={form}
            layout="vertical"
            name="form_in_modal"
            onFinish={handleSubmit}
          >
            <Form.Item
              name="email"
              rules={[
                {
                  required: true,
                  message: "Required",
                },
                {
                  message: "invalid email!",
                  type: "email",
                },
              ]}
            >
              <Input
                placeholder="Enter Email"
                prefix={<UserOutlined />}
                size="large"
              />
            </Form.Item>

            <Form.Item style={{ marginTop: "20px" }}>
              {isActive === false ? (
                <Button
                  className="login-form-button"
                  htmlType="submit"
                  type="primary"
                  block
                >
                  Submit
                </Button>
              ) : (
                <Button
                  className="login-form-button"
                  htmlType="submit"
                  type="primary"
                  block
                  disabled
                >
                  <Spin
                    style={{
                      justifyContent: "center",
                      alignItems: "center",
                      display: "flex",
                    }}
                  />
                </Button>
              )}
            </Form.Item>
          </Form>
        </div>
      )}
    </Layout>
  );
};

export default ForgetPassword;
