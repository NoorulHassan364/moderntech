import React, { useState } from "react";
import api from "../../../api";
import { Form, Input, Modal, Spin } from "antd";
import { json, Link, useNavigate } from "react-router-dom";
import "./style.css";

const VerifyModal = ({ codeModal, setCodeModal, userId }) => {
  const navigate = useNavigate();
  const [loader, setLoader] = useState(false);
  const data = localStorage.getItem("user");
  const email = JSON.parse(data)?.email;

  const [form] = Form.useForm();
  const handleSubmitCode = async (values) => {
    let result = await api.post("/auth/emailVerify", values);

    if (result.status == 200) {
      localStorage.setItem("email", JSON.stringify(result?.data?.email));
      navigate("/onBoarding");
      // localStorage.setItem("token", JSON.stringify(result?.data?.token));
    }
    setLoader(false);
  };

  const handleResendSendCode = async () => {
    setLoader(true);
    let result = await api.post("/resendEmailVerify", { id: userId });
    if (result.status === 200) {
      console.log("token send successfully");
      setLoader(false);
    }
  };

  return (
    <div>
      <Modal
        open={codeModal}
        title="Email Verification"
        okText="Submit"
        cancelText="Cancel"
        onCancel={() => setCodeModal(false)}
        maskClosable={false}
        onOk={() => {
          form
            .validateFields()
            .then((values) => {
              form.resetFields();
              handleSubmitCode(values);
            })
            .catch((info) => {
              console.log("Validate Failed:", info);
            });
        }}
      >
        <Form
          form={form}
          layout="vertical"
          name="form_in_modal"
          className="verify_modal"
        >
          <Form.Item
            name="token"
            rules={[
              {
                required: true,
                message: "Please input the Code",
              },
            ]}
          >
            <Input placeholder="Enter Verification Code" />
          </Form.Item>
          <div
            style={{
              display: "flex",
              width: "100%",
              alignItems: "center",
            }}
          >
            <div>Didn't get code?</div>
            {loader ? (
              <Spin style={{ marginLeft: "6px" }} />
            ) : (
              <Link
                to="#"
                onClick={() => handleResendSendCode()}
                style={{ marginLeft: "0.3rem" }}
              >
                resend
              </Link>
            )}
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default VerifyModal;
