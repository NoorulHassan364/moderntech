import { Checkbox, Form, Input, Select, Spin } from "antd";
import { Content } from "antd/es/layout/layout";
import React, { useState } from "react";
import api from "../../../api";
import { Link, useNavigate } from "react-router-dom";

const Login = ({ setActive, setCodeModal, setUserId }) => {
  const [loader, setLoader] = useState(false);

  const navigate = useNavigate();
  const onHandleSubmit = async (values) => {
    // alert(JSON.stringify(values));
    setLoader(true);
    let result = await api.post("/auth/signin", values);
    if (result.status == 200) {
      localStorage.setItem("user", JSON.stringify(result?.data?.data));
      // localStorage.setItem("token", JSON.stringify(result?.data?.token));
      navigate("/dashboard");
    } else if (result.response.status == 401) {
      setUserId(result.response.data?._id);
      setCodeModal(true);
    }
    setLoader(false);
  };
  return (
    <Content>
      <Form className="signup-form" onFinish={onHandleSubmit}>
        <div>
          <div className="form-title">Email</div>
          <Form.Item
            name="email"
            rules={[
              { required: true, message: "required!" },
              { type: "email", message: "invalid email" },
            ]}
          >
            <Input
              type="email"
              placeholder="example@gmail.com"
              autoComplete="off"
              className="input"
            />
          </Form.Item>
        </div>
        <div style={{ position: "relative" }}>
          <div className="form-title">Password</div>
          <Form.Item
            name="password"
            rules={[
              { required: true, message: "required!" },
              { min: 6, message: "at-least 6 characters" },
            ]}
          >
            <Input
              type="password"
              placeholder="••••••"
              autoComplete="off"
              className="input"
            />
          </Form.Item>
          <div style={{ textAlign: "right", marginBottom: "6px" }}>
            <Link to="/forget-password">Forget Password?</Link>
          </div>
        </div>
        {loader ? (
          <div style={{ textAlign: "center" }}>
            <Spin />
          </div>
        ) : (
          <button>Login</button>
        )}{" "}
      </Form>
    </Content>
  );
};

export default Login;
