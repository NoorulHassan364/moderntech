import { Checkbox, Form, Input, Spin } from "antd";
import { Content } from "antd/es/layout/layout";
import React, { useState } from "react";
import api from "../../../api";
import { useNavigate } from "react-router-dom";

const AccountSetup = ({ uId }) => {
  const [form] = Form.useForm();
  const [loader, setLoader] = useState(false);
  const [email, setEmail] = useState("");
  const navigate = useNavigate();

  const onHandleSubmit = async (values) => {
    console.log(values);
    setLoader(true);
    const result = await api.patch(`/auth/${uId}`, values);
    navigate(`/auth/?login=${true}`);
    window.location = `/auth/?login=${true}`;
    form.resetFields();
    setLoader(false);
  };
  return (
    <Content>
      <Form className="signup-form" onFinish={onHandleSubmit} form={form}>
        <div>
          <div className="form-title">Name</div>
          <Form.Item
            name="name"
            rules={[{ required: true, message: "required!" }]}
          >
            <Input
              className="input"
              type="text"
              placeholder="Name"
              autoComplete="off"
            />
          </Form.Item>
        </div>
        <div>
          <div className="form-title">Company Name</div>
          <Form.Item
            name="companyName"
            rules={[{ required: true, message: "required!" }]}
          >
            <Input
              className="input"
              type="text"
              placeholder="Company Name"
              autoComplete="off"
            />
          </Form.Item>
        </div>

        <div>
          <div className="form-title">Phone</div>
          <Form.Item name="phone">
            <Input
              className="input"
              type="text"
              placeholder="Phone"
              autoComplete="off"
            />
          </Form.Item>
        </div>

        <div>
          <div className="form-title">Password</div>
          <Form.Item
            name="password"
            rules={[
              { required: true, message: "required!" },
              { min: 6, message: "at-least 6 characters" },
            ]}
          >
            <Input.Password className="input" placeholder="••••••" />
          </Form.Item>
        </div>
        <div>
          <div className="form-title">Confirm Password</div>

          <Form.Item
            name="confirm"
            dependencies={["password"]}
            hasFeedback
            rules={[
              {
                required: true,
                message: "Please confirm your password!",
              },
              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue("password") === value) {
                    return Promise.resolve();
                  }
                  return Promise.reject(
                    new Error("The new password that you entered do not match!")
                  );
                },
              }),
            ]}
          >
            <Input.Password className="input" placeholder="••••••" />
          </Form.Item>
        </div>
        <div>
          <Form.Item
            name="terms"
            valuePropName="checked"
            dependencies={["password"]}
            rules={[
              {
                validator: (_, value) =>
                  value
                    ? Promise.resolve()
                    : Promise.reject(
                        new Error(
                          "Please accept the terms of service and privacy policy to continue."
                        )
                      ),
              },
            ]}
          >
            <Checkbox>
              I accept the{" "}
              <span style={{ fontWeight: "bold" }}>terms of service</span> and
              <span style={{ fontWeight: "bold" }}> privacy policy</span> to
              continue
            </Checkbox>
          </Form.Item>
        </div>
        {loader ? (
          <div style={{ textAlign: "center" }}>
            <Spin />
          </div>
        ) : (
          <button>Submit</button>
        )}
      </Form>
    </Content>
  );
};

export default AccountSetup;
