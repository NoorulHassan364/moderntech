// import { Button, Form, Modal, Popconfirm, Table } from "antd";
// import React, { useEffect, useState } from "react";
// import AddJob from "../job/addJob";
// import { MdDelete, MdEdit } from "react-icons/md";
// import { FaEye } from "react-icons/fa";
// import api from "../../api";
// import { useNavigate } from "react-router-dom";

// const Dashboard = ({ user }) => {
//   const navigate = useNavigate();
//   const [initialValues, setInitialValues] = useState(null);
//   const [open, setOpen] = useState(false);
//   const [editJob, setEditJob] = useState(false);
//   const [data, setData] = useState([]);
//   const [form] = Form.useForm();

//   const deleteJob = async (id) => {
//     let res = await api.delete(`/job/${id}`);
//     if (res.status == 200) {
//       let arr = data?.filter((el) => el._id !== id);
//       setData(arr);
//     }
//   };

//   let columns = [
//     { title: "Title", dataIndex: "title" },
//     { title: "Description", dataIndex: "description" },
//     { title: "Category", dataIndex: "category" },
//     {
//       title: "Date",
//       dataIndex: "createdAt",
//       render: (val) => <div>{new Date(val).toLocaleDateString()}</div>,
//     },
//     {
//       title: "Action",
//       render: (val, record) => (
//         <div
//           style={{ display: "flex", alignItems: "center", columnGap: "4px" }}
//         >
//           <MdEdit
//             cursor="pointer"
//             size={20}
//             color="#8C63AA"
//             onClick={() => handleEdit(record)}
//           />
//           <FaEye
//             cursor="pointer"
//             size={20}
//             onClick={() => navigate(`/dashboard/job-detail/${record?._id}`)}
//           />
//           <Popconfirm
//             title="Sure to delete?"
//             onConfirm={() => deleteJob(record?._id)}
//           >
//             <MdDelete cursor="pointer" size={20} color="red" />
//           </Popconfirm>
//         </div>
//       ),
//     },
//   ];

//   let columns2 = [
//     {
//       title: "Homeowner",
//       dataIndex: "homeowner",
//       render: (val, record) => <div>{record?.homeowner?.name}</div>,
//     },
//     { title: "Title", dataIndex: "title" },
//     { title: "Description", dataIndex: "description" },
//     { title: "Category", dataIndex: "category" },
//     // { title: "Views", dataIndex: "views" },
//     {
//       title: "Date",
//       dataIndex: "createdAt",
//       render: (val) => <div>{new Date(val).toLocaleDateString()}</div>,
//     },
//     {
//       title: "Action",
//       render: (val, record) => (
//         <div
//           style={{ display: "flex", alignItems: "center", columnGap: "4px" }}
//         >
//           <FaEye
//             cursor="pointer"
//             size={20}
//             onClick={() => navigate(`/dashboard/job-detail/${record?._id}`)}
//           />
//         </div>
//       ),
//     },
//   ];

//   const getJobs = async (id) => {
//     let res;
//     if (user?.role == "homeowner") {
//       res = await api.get(`/job/${id}`);
//     } else {
//       res = await api.get(`/job`);
//     }
//     if (res.status == 200) {
//       setData(res.data);
//     }
//   };

//   useEffect(() => {
//     if (user) {
//       getJobs(user?._id);
//     }
//   }, [data]);

//   const handleEdit = (elem) => {
//     console.log("hi");
//     setOpen(true);
//     setInitialValues(elem);
//     setEditJob(elem);
//   };

//   const handleCancel = () => {
//     setInitialValues(null);
//     form.resetFields();
//     setOpen(false);
//   };

//   return (
//     <div className="job-section">
//       {user?.role == "homeowner" && (
//         <Button onClick={() => setOpen(true)}>Add Job</Button>
//       )}
//       <Modal
//         open={open}
//         footer={null}
//         style={{ height: "400px" }}
//         onCancel={handleCancel}
//       >
//       <AddJob
//         setOpen={setOpen}
//         initialValues={initialValues}
//         setData={setData}
//         data={data}
//         setInitialValues={setInitialValues}
//         form={form}
//       />
//       {/* </Modal> */}
//       <Table
//         columns={user?.role == "homeowner" ? columns : columns2}
//         dataSource={data}
//       />
//     </div>
//   );
// };

// export default Dashboard;
