import React from "react";
import "./style.css";
import { Avatar, Menu, Popover } from "antd";
import { UserOutlined } from "@ant-design/icons";
import logoImg from "../../assets/logo.jpg";
const Navbar = () => {
  return (
    <div className="navbar_main">
      <img src={logoImg} className="navbar_logo" />
      <div className="navRight">
        <Popover
          content={
            <Menu>
              <Menu.Item
                onClick={() => {
                  localStorage.removeItem("user");
                  window.location.href = "/auth";
                }}
              >
                Logout
              </Menu.Item>
            </Menu>
          }
          trigger="click"
        >
          <Avatar shape="circle" icon={<UserOutlined />} size={32} />
        </Popover>
      </div>
    </div>
  );
};

export default Navbar;
