import React, { startTransition, useEffect, useState } from "react";
import {
  Button,
  Col,
  message,
  Steps,
  Row,
  Form,
  Table,
  Popconfirm,
  Modal,
  Input,
  Spin,
} from "antd";
import Step1Form from "./steps/Step1Form";
import Step2Form from "./steps/Step2Form";
import Step3Form from "./steps/Step3Form";
import { useLocation, useNavigate } from "react-router-dom";
import api from "../../api";
import useWindowDimensions from "../../helpers/getWindowDimenssions";
import { MdDelete, MdEdit } from "react-icons/md";
import { FaEye } from "react-icons/fa";
import TextArea from "antd/es/input/TextArea";
const { Step } = Steps;

function StepFormPage() {
  const navigate = useNavigate();
  const [current, setCurrent] = useState(0);
  const [initialValues, setInitialValues] = useState(null);
  const user = JSON.parse(localStorage.getItem("user"));
  const { height, width } = useWindowDimensions();
  const [open, setOpen] = useState(false);
  const [openInvite, setOpenInvite] = useState(false);
  const [editJob, setEditJob] = useState(false);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [inviteFleet, setInviteFleet] = useState(null);
  const [ownerInfo, setOwnerInfo] = useState(null);
  const [ownerInfoModal, setOwnerInfoModal] = useState(false);
  const [form] = Form.useForm();
  const [formInvite] = Form.useForm();

  let columns = [
    { title: "Fleet Name", dataIndex: "fleetName" },
    { title: "Description", dataIndex: "fleetDescription", width: 250 },
    {
      title: "Total Vehicles",
      render: (val) => {
        return 0;
      },
    },
    {
      title: "Company Owner",
      // dataIndex: "category",
      render: (val) => {
        return !val?.IscompanyOwnerInvited ? (
          <Button
            onClick={() => handleInvite(val)}
            type="primary"
            disabled={val?.IscompanyOwnerInvited}
          >
            Invite
          </Button>
        ) : (
          <Button onClick={() => handleOwneInfo(val)} type="primary">
            See Owner Info
          </Button>
        );
      },
    },
    {
      title: "Vehicles",
      // dataIndex: "category",
      render: (val) => {
        return <Button type="primary">Manage Vehicles</Button>;
      },
    },
    {
      title: "Date",
      dataIndex: "createdAt",
      render: (val) => <div>{new Date(val).toLocaleDateString()}</div>,
    },
    {
      title: "Action",
      render: (val, record) => (
        <div
          style={{ display: "flex", alignItems: "center", columnGap: "4px" }}
        >
          <MdEdit
            cursor="pointer"
            size={20}
            color="#8C63AA"
            onClick={() => handleEdit(record)}
          />
          {/* <FaEye
            cursor="pointer"
            size={20}
            onClick={() => navigate(`/dashboard/job-detail/${record?._id}`)}
          /> */}
          {user?.role == "admin" && (
            <Popconfirm
              title="Sure to delete?"
              onConfirm={() => deleteFleet(record?._id)}
            >
              <MdDelete cursor="pointer" size={20} color="red" />
            </Popconfirm>
          )}
        </div>
      ),
    },
  ];

  const handleOwneInfo = (fleet) => {
    setOwnerInfo(fleet?.companyOwner);
    setOwnerInfoModal(true);
  };

  const handleInvite = (fleet) => {
    setInviteFleet(fleet);
    debugger;
    setOpenInvite(true);
  };

  const handleCancelInviteModal = () => {
    setInviteFleet(null);
    setOpenInvite(false);
  };

  const deleteFleet = async (id) => {
    let res = await api.delete(`/fleet/${id}`);
    let arr = data?.filter((el) => el._id !== id);
    setData(arr);
  };

  const getFleets = async (id) => {
    let user = JSON.parse(localStorage.getItem("user"));
    let res = await api.get(`/fleet/${user?._id}`);
    debugger;
    setData(res.data?.data);
  };

  useEffect(() => {
    getFleets();
  }, []);

  const handleEdit = (elem) => {
    form.setFieldsValue(elem);
    setInitialValues(elem);
    setOpen(true);
  };

  const handleCancel = () => {
    form.setFieldsValue({ fleetName: "", fleetDescription: "" });
    setInitialValues({ fleetName: "", fleetDescription: "" });
    // form.resetFields();
    setOpen(false);
  };

  const onFinish = async (values) => {
    console.log(values);
    setLoading(true);
    let res;
    if (initialValues && initialValues?.fleetName !== "") {
      res = await api.patch(`/fleet/${initialValues?._id}`, values);
      let asd = data?.map((el) => {
        if (el?._id == initialValues?._id) {
          return res?.data?.data;
        } else {
          return el;
        }
      });
      console.log(asd);
      setData(asd);
    } else {
      res = await api.post(`/fleet`, values);
      setData((state) => [...state, res.data?.data]);
    }
    setLoading(false);
    handleCancel();
  };

  const onFinishInvite = async (values) => {
    console.log(values);
    let res = await api.post(`/fleet/invite/${inviteFleet?._id}`, values);
    let asd = data?.map((el) => {
      if (el?._id == inviteFleet?._id) {
        return res?.data?.data;
      } else {
        return el;
      }
    });
    console.log(asd);
    setData(asd);
    setInviteFleet(null);
    setOpenInvite(false);
  };

  return (
    <div>
      <Modal
        open={open}
        footer={null}
        style={{ height: "400px" }}
        onCancel={handleCancel}
      >
        <div className="steps_onBoarding">
          <div className="step-form">
            <div className="header">Fleet Detail</div>
            <Form
              initialValues={{
                remember: true,
              }}
              onFinish={onFinish}
              form={form}
              layout="vertical"
            >
              <Form.Item
                name="fleetName"
                label="Fleet Name"
                rules={[
                  {
                    required: true,
                    message: "Required!",
                  },
                ]}
                initialValue={initialValues?.fleetName}
              >
                <Input placeholder="Fleet Name" />
              </Form.Item>
              <Form.Item
                name="fleetDescription"
                label="Fleet Description"
                initialValue={initialValues?.fleetDescription}
              >
                <TextArea placeholder="Description" rows={4} />
              </Form.Item>

              <div style={{ marginTop: "12px" }}>
                {loading ? (
                  <Spin />
                ) : (
                  <Button
                    type="primary"
                    htmlType="submit"
                    style={{ width: "9rem", height: "2.5rem" }}
                  >
                    Submit
                  </Button>
                )}
              </div>
            </Form>
          </div>
        </div>
      </Modal>

      {/* Invite Modal  */}
      <Modal
        open={openInvite}
        footer={null}
        style={{ height: "400px" }}
        onCancel={handleCancelInviteModal}
      >
        <div className="steps_onBoarding">
          <div className="step-form">
            <div className="header">
              Invite Company to {inviteFleet?.fleetName}
            </div>
            <Form
              initialValues={{
                remember: true,
              }}
              onFinish={onFinishInvite}
              form={formInvite}
              layout="vertical"
            >
              <Form.Item
                name="email"
                label="Email"
                rules={[
                  {
                    required: true,
                    message: "Required!",
                  },
                ]}
                initialValue={initialValues?.email}
              >
                <Input placeholder="Email" />
              </Form.Item>

              <div style={{ marginTop: "12px" }}>
                {loading ? (
                  <Spin />
                ) : (
                  <Button
                    type="primary"
                    htmlType="submit"
                    style={{ width: "9rem", height: "2.5rem" }}
                  >
                    Submit
                  </Button>
                )}
              </div>
            </Form>
          </div>
        </div>
      </Modal>

      {/* Owner Info Modal  */}
      <Modal
        open={ownerInfoModal}
        footer={null}
        style={{ height: "400px" }}
        onCancel={() => {
          setOwnerInfoModal(false);
        }}
      >
        <div className="steps_onBoarding">
          <div className="step-form">
            <div className="header">Company Owner Info</div>
            <div className="ownerInfo">
              {ownerInfo?.name && (
                <>
                  <div className="infoInner">
                    <h3>Name:</h3>
                    <p>{ownerInfo?.name}</p>
                  </div>
                  <div className="infoInner">
                    <h3>Company Name:</h3>
                    <p>{ownerInfo?.companyName}</p>
                  </div>
                  <div className="infoInner">
                    <h3>Phone:</h3>
                    <p>{ownerInfo?.phone}</p>
                  </div>
                </>
              )}

              <div className="infoInner">
                <h3>Email:</h3>
                <p>{ownerInfo?.email}</p>
              </div>
              {!ownerInfo?.name && (
                <div className="infoInner">
                  <h3>Status:</h3>
                  <p>Pending</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </Modal>

      <div style={{ textAlign: "end", margin: "0rem 0rem 0.5rem 0rem" }}>
        {user?.role == "admin" && (
          <Button onClick={() => setOpen(true)} type="primary">
            Add Fleet
          </Button>
        )}
      </div>
      <Table
        columns={
          user?.role !== "admin"
            ? columns?.filter((el) => el?.title !== "Company Owner")
            : columns
        }
        dataSource={data}
      />
    </div>
  );
}

export default StepFormPage;
