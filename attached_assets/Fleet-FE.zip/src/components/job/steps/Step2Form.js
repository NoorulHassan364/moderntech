import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Button,
  Checkbox,
  Form,
  Input,
  DatePicker,
  Select,
  InputNumber,
  Radio,
} from "antd";
import "./style.css";
import moment from "moment";
import { categories } from "../../../helpers/index";
const { Option } = Select;

const Step2Form = ({
  setInitialValues,
  setClickNext,
  initialValues,
  setCurrent,
  current,
  form,
}) => {
  const [options, setOptions] = useState([]);

  const onFinish = (values) => {
    console.log("Success step1:", values);
    setInitialValues({ ...initialValues, services: values.services });
    setClickNext(true);
    setCurrent(current + 1);
  };

  const handleBack = () => {
    setCurrent(current - 1);
    setInitialValues({ ...initialValues, services: [] });
  };

  useEffect(() => {
    let res = categories?.find((el) => el.title == initialValues?.category);
    if (res) setOptions(res?.options);
  }, []);

  return (
    <div className="step-form">
      <div className="header">
        Which Services you need for {initialValues?.category}?
      </div>
      <Form onFinish={onFinish} form={form} style={{ margin: "0rem 2rem" }}>
        <Form.Item
          name="services"
          rules={[
            {
              required: true,
              message: "Required!",
            },
          ]}
          initialValue={
            initialValues?.services?.split &&
            initialValues?.services?.split(",")
          }
        >
          <Checkbox.Group
            className="checkboxes"
            onChange={(e) => console.log(e)}
            defaultValue={
              initialValues?.services?.split &&
              initialValues?.services?.split(",")
            }
          >
            {options?.map((el) => (
              <div style={{ margin: "2px 0px" }}>
                <Checkbox value={el}>{el}</Checkbox>
              </div>
            ))}
          </Checkbox.Group>
        </Form.Item>
        <div style={{ textAlign: "center" }}>
          <Button
            type="default"
            onClick={handleBack}
            style={{ marginRight: "12px" }}
          >
            Back
          </Button>
          <Button type="primary" htmlType="submit">
            Next
          </Button>
        </div>
      </Form>
    </div>
  );
};
export default Step2Form;
