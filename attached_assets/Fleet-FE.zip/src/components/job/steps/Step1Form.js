import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Button,
  Checkbox,
  Form,
  Input,
  DatePicker,
  Select,
  InputNumber,
  Radio,
} from "antd";
import "./style.css";
import moment from "moment";
import { categories } from "../../../helpers/index";
const { Option } = Select;

const Step1Form = ({
  setInitialValues,
  setClickNext,
  initialValues,
  setCurrent,
  current,
  form,
}) => {
  // const [form] = Form.useForm();
  const onFinish = (values) => {
    console.log("Success step1:", values, initialValues);
    if (initialValues?.category !== values?.category) {
      setInitialValues({ ...initialValues, ...values, services: [] });
    } else {
      setInitialValues({ ...initialValues, ...values });
    }
    setClickNext(true);
    setCurrent(current + 1);
  };

  return (
    <div className="step-form" style={{ textAlign: "center" }}>
      <div className="header">Choose Category</div>
      <Form onFinish={onFinish} form={form}>
        <Form.Item
          name="category"
          rules={[
            {
              required: true,
              message: "Required!",
            },
          ]}
        >
          <Select
            placeholder="Select Category"
            size="large"
            style={{ width: "220px", margin: "auto" }}
            // defaultValue={initialValues?.category}
          >
            {categories?.map((el) => (
              <Select.Option value={el?.title}>{el?.title}</Select.Option>
            ))}
          </Select>
        </Form.Item>
        <div style={{ textAlign: "center" }}>
          <Button type="primary" htmlType="submit">
            Next
          </Button>
        </div>
      </Form>
    </div>
  );
};
export default Step1Form;
