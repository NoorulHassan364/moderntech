import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Button,
  Checkbox,
  Form,
  Input,
  DatePicker,
  Select,
  InputNumber,
  Radio,
  Upload,
  Row,
  Col,
  Spin,
  message,
} from "antd";
import "./style.css";
import moment from "moment";
import TextArea from "antd/es/input/TextArea";
import { BsUpload } from "react-icons/bs";
import { MdDelete } from "react-icons/md";
import api from "../../../api";

const { Option } = Select;

const Step2Form = ({
  setInitialValues,
  setClickNext,
  initialValues,
  setCurrent,
  current,
  user,
  setOpen,
  setData,
  data,
  form,
  handleCancel,
}) => {
  const [fileList, setFileList] = useState([]);
  const [loading, setLoading] = useState(false);
  const onFinish = async (values) => {
    if (fileList.length == 0) {
      message.error({ content: "Please upload photos" });
      return;
    }
    setLoading(true);
    if (!initialValues?._id) {
      let arr = fileList?.map((el) => {
        return el?.originFileObj;
      });
      console.log(arr);
      const formData = new FormData();
      formData.append("category", initialValues.category);
      formData.append("services", initialValues.services);
      formData.append("title", values.title);
      formData.append("description", values.description);
      // formData.append("photos", arr);
      arr.forEach((image) => {
        formData.append("photos", image); // 'images' is the key you can use to access this data on the server side
      });

      let res = await api.post(`/job/${user?._id}`, formData);
      if (res.status == 201) {
        handleCancel();
        setData((state) => [...state, res.data]);
      }
    } else {
      console.log(fileList);
      let objArr = fileList?.filter((el) => el.uid);
      if (objArr.length > 0) {
        let arr = fileList?.map((el) => {
          return el?.originFileObj;
        });
        console.log(arr);
        const formData = new FormData();
        formData.append("category", initialValues.category);
        formData.append("services", initialValues.services);
        formData.append("title", values.title);
        formData.append("description", values.description);
        // formData.append("photos", arr);
        arr.forEach((image) => {
          formData.append("photos", image); // 'images' is the key you can use to access this data on the server side
        });

        let res = await api.patch(`/job/${initialValues?._id}`, formData);
        if (res.status == 200) {
          handleCancel();
          let arr = data?.map((el) =>
            initialValues?._id == res.data._id ? res.data : el
          );
          setData(arr);
        }
      } else {
        let res = await api.patch(`/job/${initialValues?._id}`, {
          ...initialValues,
          services: initialValues.services?.join(","),
          title: values.title,
          description: values?.description,
          photos: fileList,
        });
        if (res.status == 200) {
          handleCancel();
          let arr = data?.map((el) =>
            initialValues?._id == res.data._id ? res.data : el
          );
          console.log(data);
          setData(arr);
        }
      }
    }

    setLoading(false);
  };

  const handleBack = () => {
    setCurrent(current - 1);
  };

  const handleUpload = (event) => {
    console.log(event);
    setFileList(event.fileList);
    setInitialValues({ ...initialValues, photos: event.fileList });
  };

  const handleDelete = (event) => {
    let arr;
    if (event?.uid) {
      arr = fileList?.filter((el) => el?.uid !== event?.uid);
    } else {
      arr = fileList?.filter((el) => el !== event);
    }
    setFileList(arr);
  };

  useEffect(() => {
    if (initialValues?.photos) {
      setFileList(initialValues.photos);
    }
  }, []);

  return (
    <div className="step-form">
      <div className="header">Job Detail</div>
      <Form
        initialValues={{
          remember: true,
        }}
        onFinish={onFinish}
        form={form}
      >
        <Form.Item
          name="title"
          rules={[
            {
              required: true,
              message: "Required!",
            },
          ]}
          initialValue={initialValues?.title}
        >
          <Input
            placeholder="Enter Title"
            onChange={(e) =>
              setInitialValues({ ...initialValues, title: e.target.value })
            }
          />
        </Form.Item>
        <Form.Item
          name="description"
          rules={[
            {
              required: true,
              message: "Required!",
            },
          ]}
          initialValue={initialValues?.description}
        >
          <TextArea
            placeholder="Write Description"
            rows={4}
            onChange={(e) =>
              setInitialValues({
                ...initialValues,
                description: e.target.value,
              })
            }
          />
        </Form.Item>

        <Form.Item>
          <Upload onChange={handleUpload} accept="image/*" multiple>
            <Button type="dashed" icon={<BsUpload />}>
              Upload Photos
            </Button>
          </Upload>
        </Form.Item>

        <Row style={{ maxHeight: "300px", overflowY: "auto" }}>
          {fileList?.map((elem) => (
            <Col md={8}>
              <div className="image-section">
                <MdDelete
                  size={24}
                  color="red"
                  cursor="pointer"
                  onClick={() => handleDelete(elem)}
                  className="delete-icon"
                />
                <img
                  src={
                    elem?.originFileObj
                      ? URL.createObjectURL(elem?.originFileObj)
                      : elem
                  }
                  height={100}
                  width={150}
                />
              </div>
            </Col>
          ))}
        </Row>

        <div style={{ textAlign: "center", marginTop: "12px" }}>
          <Button
            type="default"
            onClick={handleBack}
            style={{ marginRight: "12px" }}
          >
            Back
          </Button>
          {loading ? (
            <Spin />
          ) : (
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          )}
        </div>
      </Form>
    </div>
  );
};
export default Step2Form;
