import React, { useEffect, useState } from "react";
import api from "../../api";
import { useParams } from "react-router-dom";
import {
  Button,
  Col,
  Form,
  Image,
  Input,
  Modal,
  Row,
  Spin,
  Table,
  Tabs,
  Tag,
} from "antd";
import "./style.css";
import TextArea from "antd/es/input/TextArea";

const JobDetail = ({ user }) => {
  const [loader, setLoader] = useState(false);
  const [form] = Form.useForm();
  const [open, setOpen] = useState(false);
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [proposals, setProposals] = useState([]);
  const getJob = async (id) => {
    setLoader(true);
    let res = await api.get(`/job/get-job/${id}`);
    let res2 = await api.get(`/proposal/get-job-proposals/${id}`);

    if (res.status == 200) {
      setData(res.data);
    }

    if (res2.status == 200) {
      setProposals(res2.data);
    }
    setLoader(false);
  };

  useEffect(() => {
    if (id) getJob(id);
  }, []);

  const handleCancel = () => {
    setOpen(false);
    form.resetFields();
  };

  const onFinish = async (values) => {
    let res = await api.post(`/proposal/${user?._id}`, { ...values, job: id });
    if (res.status == 201) {
      setData({ ...data, proposal: [...data?.proposal, user?._id] });
      handleCancel();
    }
  };

  let columns = [
    {
      title: "Contractor",
      dataIndex: "contractor",
      render: (val, record) => <div>{record?.contractor?.name}</div>,
    },
    {
      title: "Email",
      dataIndex: "email",
      render: (val, record) => <div>{record?.contractor?.email}</div>,
    },
    {
      title: "Text",
      dataIndex: "text",
      render: (val, record) => <div>{record?.text}</div>,
    },
    { title: "Budget", dataIndex: "budget" },
    { title: "timeline", dataIndex: "timeline" },

    {
      title: "Action",
      render: (val, record) => <Button type="primary">Accept</Button>,
    },
  ];

  return (
    <div className="detail-main">
      <Tabs>
        <Tabs.TabPane tab="Job Detail" key={1}>
          {loader ? (
            <div
              style={{
                height: "100vh",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Spin />
            </div>
          ) : (
            <div className="job-detail">
              <div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    margin: "7px 0px 0px 0px",
                  }}
                >
                  <div className="title">{data?.title}</div>

                  {user?.role == "contractor" && (
                    <>
                      {!data?.proposal?.includes(user?._id) ? (
                        <Button type="primary" onClick={() => setOpen(true)}>
                          Send Proposal
                        </Button>
                      ) : (
                        <Tag
                          color="purple"
                          style={{
                            height: "fit-content",
                            fontSize: "17px",
                            padding: "10px",
                          }}
                        >
                          Proposal sended
                        </Tag>
                      )}
                    </>
                  )}
                </div>
                <div className="category">Category: {data?.category}</div>
                <div className="heading">Services:</div>
                <ul className="services">
                  {data?.services.split(",").map((el) => (
                    <li>{el}</li>
                  ))}
                </ul>

                <div className="description">
                  <div className="heading">Details</div>
                  <div>{data?.description}</div>
                </div>
                <div className="images-section">
                  <Row>
                    {data?.photos?.map((el) => (
                      <Col md={5}>
                        <Image
                          src={el}
                          alt="image"
                          height={150}
                          width={150}
                          style={{ border: "1px solid gray" }}
                        />
                      </Col>
                    ))}
                  </Row>
                </div>
              </div>
            </div>
          )}
        </Tabs.TabPane>
        {user?.role == "homeowner" && (
          <Tabs.TabPane
            tab={`Proposals ${proposals.length > 0 ? proposals.length : ""}`}
            key={2}
          >
            <Table columns={columns} dataSource={proposals} />
          </Tabs.TabPane>
        )}
      </Tabs>
      <Modal
        open={open}
        footer={null}
        onCancel={handleCancel}
        title="Send Proposal"
      >
        <Form
          initialValues={{
            remember: true,
          }}
          onFinish={onFinish}
          form={form}
        >
          <Form.Item
            name="text"
            rules={[
              {
                required: true,
                message: "Required!",
              },
            ]}
          >
            <TextArea placeholder="Write Text..." rows={5} />
          </Form.Item>
          <Form.Item
            name="budget"
            rules={[
              {
                required: true,
                message: "Required!",
              },
            ]}
          >
            <Input placeholder="Enter your budget" />
          </Form.Item>
          <Form.Item
            name="timeline"
            rules={[
              {
                required: true,
                message: "Required!",
              },
            ]}
          >
            <Input type="date" placeholder="Enter Timeline" />
          </Form.Item>
          <Button type="primary" htmlType="submit">
            Submit
          </Button>
        </Form>
      </Modal>
    </div>
  );
};

export default JobDetail;
