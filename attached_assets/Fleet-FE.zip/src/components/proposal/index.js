import { Button, Modal, Popconfirm, Table, Tag } from "antd";
import React, { useEffect, useState } from "react";
import { MdDelete, MdEdit } from "react-icons/md";
import { FaEye } from "react-icons/fa";
import api from "../../api";

const Dashboard = ({ user }) => {
  const [data, setData] = useState([]);

  let columns = [
    {
      title: "Title",
      dataIndex: "title",
      render: (val, record) => <div>{record?.job?.title}</div>,
    },
    {
      title: "Description",
      dataIndex: "description",
      render: (val, record) => <div>{record?.job?.description}</div>,
    },
    {
      title: "Category",
      dataIndex: "category",
      render: (val, record) => <div>{record?.job?.category}</div>,
    },
    { title: "Budget", dataIndex: "budget" },
    { title: "Timeline", dataIndex: "timeline" },

    {
      title: "Status",
      render: (val, record) => <Tag color="blue">Pending</Tag>,
    },
  ];

  const getProposals = async (id) => {
    let res = await api.get(`/proposal/${id}`);
    if (res.status == 200) {
      setData(res.data);
    }
  };

  useEffect(() => {
    if (user) {
      getProposals(user?._id);
    }
  }, []);

  return (
    <div className="job-section">
      <Table columns={columns} dataSource={data} />
    </div>
  );
};

export default Dashboard;
