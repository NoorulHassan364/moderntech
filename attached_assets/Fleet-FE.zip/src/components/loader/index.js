import React from "react";
import { Layout } from "antd";
import BounceLoader from "react-spinners/BounceLoader";

function Loader() {
  let [color, setColor] = React.useState("#8C63AA");

  return (
    <Layout
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "100%",
        height: "100vh",
      }}
    >
      <BounceLoader color={color} size={80} />
    </Layout>
  );
}

export default Loader;
