// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBioaOy5mQrHmrvvEUrNmaOGRSodIAfTXY",
  authDomain: "fleet-management-d56f5.firebaseapp.com",
  projectId: "fleet-management-d56f5",
  storageBucket: "fleet-management-d56f5.appspot.com",
  messagingSenderId: "97048802895",
  appId: "1:97048802895:web:6598dec928db081f0f9c3a",
  measurementId: "G-0R7VZ1YKCC",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);

const auth = getAuth(app);
const provider = new GoogleAuthProvider();

export { auth, provider };
