export const getQueryParam = (name) => {
  const searchParams = new URLSearchParams(window.location.search);
  return searchParams.get(name);
};

export const categories = [
  {
    ket: 1,
    title: "Flooring",
    options: [
      "Hardwood",
      "Laminate",
      "Vinyl",
      "Tile",
      "Carpet",
      "Bamboo",
      "Cork",
      "Concrete",
    ],
  },
  {
    ket: 1,
    title: "Roofing",
    options: [
      "repair or maintenance",
      "installation or replacement",
      "cleaning",
      "inspection",
      "Coating and Sealing",
      "Chimney and Flashing Repair",
    ],
  },
  {
    ket: 1,
    title: "Plumbing",
    options: [
      "Plumbing Fixtures",
      "Pipes and Materials",
      "Plumbing Appliances",
      "Bathroom and Kitchen Remodeling",
      "Filtration and Softening Systems",
      "Bathroom Remodeling",
    ],
  },
  {
    ket: 1,
    title: "Painting and Wall repairing",
    options: [
      "Wall patching",
      "Wall Repair and Preparation",
      "Paint stripping",
      "Rust removal",
      "Exterior Painting",
      "Interior painting",
    ],
  },
  {
    ket: 1,
    title: "Appliance",
    options: [
      "Appliance Installation",
      "Repair and Maintenance",
      "Upgrades and Retrofits",
      "Garbage Disposal Installation and Repair",
      "Water Heater Services",
      "Water Dispenser Repair",
    ],
  },
];
