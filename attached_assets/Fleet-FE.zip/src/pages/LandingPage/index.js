import React from "react";
import Navbar from "../../components/navbar";
const Index = () => {
  const user = JSON.parse(localStorage.getItem("user"));

  return (
    <>
      <Navbar />
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "88vh",
        }}
      >
        <div style={{ textAlign: "center" }}>
          <h1>Hi {user?.name}</h1>
          <h1>WELCOME TO APPLICATION</h1>
        </div>
      </div>
    </>
  );
};

export default Index;
