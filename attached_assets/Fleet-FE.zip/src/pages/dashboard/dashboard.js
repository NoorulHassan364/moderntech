import React from "react";
import Dashboard from "../../components/job/addJob";

const Index = () => {
  const user = JSON.parse(localStorage.getItem("user"));
  return <Dashboard user={user} />;
};

export default Index;
