import React from "react";
import Proposal from "../../components/proposal/index";

const Index = () => {
  const user = JSON.parse(localStorage.getItem("user"));
  return <Proposal user={user} />;
};

export default Index;
