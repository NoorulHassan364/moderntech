import React from "react";
import JobDetail from "../../components/job/jobDetail";

const Index = () => {
  const user = JSON.parse(localStorage.getItem("user"));
  return <JobDetail user={user} />;
};

export default Index;
