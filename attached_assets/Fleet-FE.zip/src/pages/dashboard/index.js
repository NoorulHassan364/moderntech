import React from "react";
import Profile from "../../components/sidebar/index";
import Navbar from "../../components/navbar/index";
import DashboardRoutes from "../../router/dashboardRoutes";

const Index = () => {
  const user = JSON.parse(localStorage.getItem("user"));
  return (
    <>
      <Navbar user={user} />
      <Profile>
        <DashboardRoutes />
      </Profile>
    </>
  );
};

export default Index;
