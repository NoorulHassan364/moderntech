import { Col, Row } from "antd";
import React, { useEffect, useState } from "react";
import image from "../../assets/360_F_308697506_9dsBYHXm9FwuW0qcEqimAEXUvzTwfzwe.jpg";
import { Content } from "antd/es/layout/layout";
import "./style.css";
import { FcGoogle } from "react-icons/fc";
import Signup from "../../components/auth/Signup/Signup";
import Login from "../../components/auth/Login/Login";
import { auth, provider } from "../../helpers/googleAuth";
import { signInWithPopup } from "firebase/auth";
import api from "../../api";
import { useNavigate } from "react-router-dom";
import VerifyModal from "../../components/auth/VerifyModal/VerifyModal";
import { getQueryParam } from "../../helpers";
import AccountSetup from "../../components/auth/AccountSetup/AccountSetup";

const Register = () => {
  const navigate = useNavigate();
  const [active, setActive] = useState("login");
  const [userId, setUserId] = useState(null);
  const [role, setRole] = useState("homeowner");
  const [codeModal, setCodeModal] = useState(false);
  const [uId, setUId] = useState(null);

  const continueWithGoogle = () => {
    signInWithPopup(auth, provider).then(async (res) => {
      let data = {
        name: res?.user?.displayName,
        email: res?.user?.email,
        photo: res?.user?.photoURL,
        token: res?.user?.accessToken,
        role: role,
      };
      console.log(data);
      let result = await api.post("/auth/signinwithgoogle", data);
      localStorage.setItem("user", JSON.stringify(result?.data));
      // localStorage.setItem("token", JSON.stringify(result?.data?.token));
      navigate("/");
    });
  };

  useEffect(() => {
    let res = getQueryParam("login");
    if (res) setActive("login");
    let account = getQueryParam("account");
    if (account) setActive("account");
    let uid = getQueryParam("uid");
    if (uid) setUId(uid);
    // let result = getQueryParam("role");
    // if (result) setRole(result);
  }, []);

  return (
    <Content style={{ height: "100vh" }}>
      <Row style={{ height: "100%" }}>
        <Col xs={24} md={14} className="section-1">
          <div className="background">
            <div className="auth-left-sec"></div>
          </div>
        </Col>
        <Col xs={24} md={10} className="section-2">
          <div>
            <div className="auth-btns">
              {/* <span
                className={active == "signup" ? "auth-btn-active" : "auth-btn"}
                onClick={() => setActive("signup")}
              >
                Sign up
              </span> */}
              {active == "login" && (
                <span
                  className={active == "login" ? "auth-btn-active" : "auth-btn"}
                  onClick={() => setActive("login")}
                >
                  Login
                </span>
              )}
              {active == "account" && (
                <span
                  className={active == "login" ? "auth-btn-active" : "auth-btn"}
                  onClick={() => setActive("account")}
                >
                  Account Setup
                </span>
              )}
            </div>

            {active == "signup" ? (
              <Signup
                setActive={setActive}
                codeModal={codeModal}
                setCodeModal={setCodeModal}
                setUserId={setUserId}
                role={role}
              />
            ) : active == "login" ? (
              <Login
                setActive={setActive}
                codeModal={codeModal}
                setCodeModal={setCodeModal}
                setUserId={setUserId}
              />
            ) : (
              <AccountSetup
                setActive={setActive}
                setUserId={setUserId}
                uId={uId}
              />
            )}
            {active !== "account" && (
              <>
                <div class="container">
                  <hr class="horizontal-line" />
                  <div class="text">or</div>
                  <hr class="horizontal-line" />
                </div>
                <div style={{ margin: "1rem 0rem" }}>
                  <button className="googleBtn" onClick={continueWithGoogle}>
                    <div>
                      <FcGoogle size={22} />
                      <div className="google_text">
                        <span>Sign In with</span> <div>Google</div>
                      </div>
                    </div>
                  </button>
                </div>
              </>
            )}

            {/* {active == "login" ? (
              <div className="alreadyAcc">
                Don't Have an account? Sign up{" "}
                <span
                  style={{
                    cursor: "pointer",
                    color: "blue",
                    textDecoration: "underline",
                  }}
                  onClick={() => setActive("signup")}
                >
                  here
                </span>
              </div>
            ) : (
              <div className="alreadyAcc">
                Already Have an account? Sign in{" "}
                <span
                  style={{
                    cursor: "pointer",
                    color: "blue",
                    textDecoration: "underline",
                  }}
                  onClick={() => setActive("login")}
                >
                  here
                </span>
              </div>
            )} */}
          </div>
        </Col>
      </Row>
      <VerifyModal
        codeModal={codeModal}
        setCodeModal={setCodeModal}
        userId={userId}
      />
    </Content>
  );
};

export default Register;
