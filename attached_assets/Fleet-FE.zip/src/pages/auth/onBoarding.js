import React, { useState } from "react";
import {
  Button,
  Col,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Radio,
  Row,
  Spin,
} from "antd";

import { useNavigate } from "react-router-dom";
import api from "../../api";
import "./style.css";

function OnBoarding() {
  const [form] = Form.useForm();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [target, setTarget] = useState("individual");

  const onFinish = async (values) => {
    const email = JSON.parse(localStorage.getItem("email"));
    setLoading(true);
    let res = await api.patch(`/auth/${email}`, values);
    setLoading(false);
    if (res.status == 200) {
      localStorage.setItem("user", JSON.stringify(res?.data));
      localStorage.removeItem("email");
      navigate("/dashboard");
    }
  };

  return (
    <Row className="on-boarding">
      <Col xs={24} md={14} className="section-1">
        <div className="background">
          <div className="auth-left-sec"></div>
        </div>
      </Col>
      <Col xs={24} md={10} className="section-2">
        <div>
          <h1 style={{ textAlign: "center" }}>Personal Information</h1>
          <div className="onBoarding_main">
            <Form
              form={form}
              onFinish={onFinish}
              autoComplete="off"
              layout="vertical"
            >
              <Form.Item
                label="Name"
                name="name"
                rules={[
                  {
                    required: true,
                    message: "Required!",
                  },
                ]}
              >
                <Input />
              </Form.Item>

              <Form.Item
                label="Phone Number"
                name="phone"
                rules={[
                  {
                    required: true,
                    message: "Required!",
                  },
                ]}
              >
                <InputNumber style={{ width: "100%" }} minLength={7} />
              </Form.Item>

              <Form.Item
                label="Address"
                name="address"
                rules={[
                  {
                    required: true,
                    message: "Required!",
                  },
                ]}
              >
                <Input />
              </Form.Item>

              <Form.Item>
                <Radio.Group
                  onChange={(e) => setTarget(e.target.value)}
                  defaultValue={"individual"}
                >
                  <Radio value="individual">Individual</Radio>
                  <Radio value="company">Company</Radio>
                </Radio.Group>
              </Form.Item>

              {target == "company" && (
                <Form.Item
                  label="Company"
                  name="company"
                  rules={[
                    {
                      required: true,
                      message: "Required!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
              )}

              <Form.Item>
                {loading ? (
                  <Spin style={{ marginLeft: "8px" }} />
                ) : (
                  <Button type="primary" htmlType="submit">
                    Submit
                  </Button>
                )}
              </Form.Item>
            </Form>
          </div>
        </div>
      </Col>
    </Row>
  );
}

export default OnBoarding;
