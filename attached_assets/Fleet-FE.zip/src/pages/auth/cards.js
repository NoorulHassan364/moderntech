import React from "react";
import Cards from "../../components/auth/cards/index";

const Index = () => {
  return <Cards />;
};

export default Index;
