import React from "react";
import ForgetPassword from "../../components/auth/forgetPassword/index";

const Index = () => {
  return <ForgetPassword />;
};

export default Index;
