import { ConfigProvider } from "antd";
import Routing from "./router/AppRoutes";
import { ToastContainer, Slide } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function App() {
  return (
    <>
      <ConfigProvider
        theme={{
          token: {
            // colorPrimary: "#8C63AA",
          },
        }}
      >
        <Routing />
        <ToastContainer
          position="top-right"
          autoClose={6000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          transition={Slide}
        />
      </ConfigProvider>
    </>
  );
}

export default App;
